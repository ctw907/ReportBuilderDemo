# chat.html — upload notes

Built 2026-07-29 from `app.html` at md5 `51e74189…` (the patched 77,380-byte build, which is what's live — the patch had already landed by the time you sent the zip).

## Upload

One file, one place: drop `chat.html` at the **root** of `ctw907/ReportBuilderDemo`, alongside `app.html`. Flat repo, `.nojekyll` already present, so it publishes as-is.

Live at `https://ctw907.github.io/ReportBuilderDemo/chat.html` once the Pages build goes green.

Nothing else changes. `app.html`, `index.html` and `report.html` are untouched — they still hash to `51e74189…`, `51e74189…` and `9c6dabbe…`. The bare Pages URL still serves the combined build.

## What it is

`app.html` minus the report canvas. 35,535 bytes, down from 77,380.

The transport is copied across verbatim — same `CONFIG`, same `flowUrl`, same `POST` with `Content-Type: text/plain;charset=UTF-8`, same `send()`, same `addMessage()`. Diffed to confirm, not eyeballed. No flow, Dataverse or Office Script change is needed.

**How answers land.** They come back as reply text plus the **Open report** and **Open in Excel** buttons that `addMessage()` already drew in the combined build. That wasn't new work — `app.html` was written to degrade to exactly this when the dashboard card can't render, so it's the designed fallback rather than a new code path. The report link still points at `report.html#<envelope>`, so the chat hands over a link and the link opens the full report.

**One thing did need building.** When the engine can't tell which entity you meant it returns an `ambiguous` envelope, and in `app.html` that picker mounts in the canvas. Left alone it would have been swallowed here and the conversation would have looked like it stalled. It now renders as a full-width bot message in the thread, and tapping a candidate fires the follow-up the same way.

**Removed:** the canvas and its empty state, the report renderer and all 35 drill targets, the print button and `finalizeForPrint()`, the data-source toggle and legend. The `@media print` block was rewritten — the old one hid `.chat`, so Ctrl+P would have printed a blank sheet; it now prints the transcript.

## Verified

`node --check` passes. 25 functional assertions pass against the real page loaded in jsdom with the flow stubbed: shell, ordinary answer with both link buttons, ambiguity picker plus candidate click-through, clarification path, network failure, HTTP 502, and a non-JSON reply. Balanced markup, 15 divs open and close.

Untested by me, because it needs a browser and a live flow: how it actually looks on screen, and a real round trip. Open it and send one request before you film.

## For filming

Two tabs — `chat.html` for the ask beats, `app.html` for the combined reveal. No toggle, no rebuild; they're separate URLs serving at the same time.

Narrow viewports drop the side borders and go edge-to-edge, so the 9:16 vertical cut of Shots 3 and 6 won't have dead margins.

## Consequence worth knowing

The repo now carries the `sig=`-signed `flowUrl` in **three** public files instead of two. The URL is the credential — anyone who views source has a callable endpoint into the workbook. Fine for a filmed demo on demo data; not fine in a client tenant, and when you rotate that signature it's now three files to edit, not two. Unchanged as an issue, just wider. The real fix is still Power Pages or an auth layer.
