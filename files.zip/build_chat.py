#!/usr/bin/env python3
"""
build_chat.py — carve chat.html out of app.html.

Anchored, not line-numbered: every cut point is located by matching the
actual text of the line, and the script aborts if an anchor moved. Run it
again after any future edit to app.html and it will either still work or
tell you exactly which anchor broke.

Cuts made (four, all contiguous):
  1. CSS  .app/.chat/.canvas layout block -> single centred column
  2. CSS  @media print block              -> transcript-appropriate print
  3. HTML <div class="canvas"> ... </div>  -> removed entirely
  4. JS   report-render engine             -> ambiguity picker only
"""
import hashlib
import re
import subprocess
import sys
from pathlib import Path

SRC = Path("/home/claude/rbd/ReportBuilderDemo-main/app.html")
OUT = Path("/home/claude/out/chat.html")

EXPECT_SRC_MD5 = "51e74189fc8fdbd88168b026a286f66e"   # patched 77,380-byte build

src = SRC.read_bytes()
got = hashlib.md5(src).hexdigest()
if got != EXPECT_SRC_MD5:
    print(f"!! app.html md5 is {got}, expected {EXPECT_SRC_MD5}", file=sys.stderr)
    print("   Base changed. Re-verify the anchors below before trusting output.", file=sys.stderr)

lines = src.decode("utf-8").split("\n")


def find(needle, start=0, end=None):
    """Index of the first line containing needle. Aborts if absent."""
    end = len(lines) if end is None else end
    for i in range(start, end):
        if needle in lines[i]:
            return i
    sys.exit(f"ANCHOR NOT FOUND: {needle!r}")


# ---------------------------------------------------------------- anchors
css_layout_a = find(".app { display: flex; height: 100vh;")
css_layout_b = find("#report .rcard {", css_layout_a)            # inclusive end
hdr_a        = find(".chat__header {", css_layout_b)

print_media  = find("@media print {")
# the block is preceded by a comment header describing the REPORT print path
# (letterhead in a thead, finalizeForPrint) — that goes too, or it survives as
# a stale comment describing machinery this page no longer has.
print_a      = find("PRINT — the chat column drops away") - 1
if "/* =" not in lines[print_a]:
    sys.exit(f"ANCHOR SHIFTED: line {print_a+1} is not a comment opener: {lines[print_a]!r}")
print_b      = find("@media (prefers-reduced-motion: reduce)", print_media)   # exclusive end

canvas_a     = find('<div class="canvas" id="canvas">')
script_a     = find("<script>", canvas_a)
canvas_b     = None                                              # closing </div> of .canvas
for i in range(script_a - 1, canvas_a, -1):
    if lines[i].strip() == "</div>":
        canvas_b = i                                             # this closes .app
        break
# the </div> above closes .app; the one before it closes .canvas
canvas_close = None
for i in range(canvas_b - 1, canvas_a, -1):
    if lines[i].strip() == "</div>":
        canvas_close = i
        break
if canvas_close is None:
    sys.exit("ANCHOR NOT FOUND: closing </div> for .canvas")

js_a         = find("Inline envelope rendering", script_a) - 1    # the /* ==== opener
js_b         = find("// UX niceties", js_a)                       # exclusive end

# sanity: the JS opener really is a comment start
if "/* =" not in lines[js_a]:
    sys.exit(f"ANCHOR SHIFTED: line {js_a+1} is not a comment opener: {lines[js_a]!r}")

# ---------------------------------------------------------------- new CSS
NEW_LAYOUT = '''  /* Single-column shell — this is the chat-only build, so the chat owns the
     whole window. The report canvas (and everything that mounts into it)
     lives in app.html; nothing renders to the right of the thread here. */
  .app { display: flex; height: 100vh; overflow: hidden; justify-content: center; }

  .chat {
    width: 100%;
    max-width: 880px;
    flex: none;
    height: 100vh;
    background: var(--panel);
    border-left: 1px solid var(--line);
    border-right: 1px solid var(--line);
    display: flex;
    flex-direction: column;
    overflow: hidden;
    box-shadow: var(--shadow);
  }
  @media (max-width: 900px) {
    .chat { max-width: none; border-left: none; border-right: none; box-shadow: none; }
  }

  /* The "which one do you mean?" picker is the only card this page draws, and
     it draws in the thread. Drop the bubble chrome so the card supplies its
     own. Specificity is .msg.msg--report so it beats .msg--bot .bubble. */
  .msg.msg--report .bubble { padding: 0; background: none; border-radius: 0; white-space: normal; }
  .msg.msg--report .rcard  { border-radius: 14px; box-shadow: 0 1px 2px rgba(16,24,40,.05), 0 14px 34px -18px rgba(16,24,40,.22); }
'''

NEW_PRINT = '''  /* Ctrl+P on a chat page should print the transcript, not a blank sheet —
     the 100vh flex shell has to be unlocked the same way app.html unlocks it
     for the report. There is no print button here; this is for the browser
     menu and the keyboard shortcut. */
  @media print {
    @page { size: letter; margin: .5in; }

    html, body { background: #fff !important; height: auto !important; min-height: 0 !important; overflow: visible !important; }
    body { font-size: 11px; color: #000; }

    .app  { display: block !important; height: auto !important; overflow: visible !important; }
    .chat {
      width: auto !important; max-width: none !important; height: auto !important;
      overflow: visible !important; border: none !important; box-shadow: none !important;
    }
    .chat__log { overflow: visible !important; height: auto !important; background: #fff !important; padding: 0 !important; }
    .chat__composer, .hint { display: none !important; }

    .msg { max-width: 100% !important; break-inside: avoid; page-break-inside: avoid; }
    .bubble { border-radius: 6px !important; }
    .msg--user .bubble { background: #eef3fe !important; color: #000 !important; }
    .msg--bot  .bubble { background: #f5f6f9 !important; color: #000 !important; }
    .bubble a.report-link { border: 1px solid #c9d2e0 !important; }

    .rcard { border: 1px solid #c9d2e0 !important; box-shadow: none !important; break-inside: avoid; }
    .rcand, .rdrill { display: none !important; }
  }

'''

# ---------------------------------------------------------------- new JS
NEW_JS = '''/* ============================================================
   Envelope handling — chat-only build.

   app.html mounts the flow's envelope as a full dashboard card in a
   right-hand canvas. There is no canvas on this page, so the report is
   not drawn here. The reply text plus the "Open report" / "Open in Excel"
   buttons that addMessage() already renders ARE the answer: you ask in
   the thread, you get an answer and a link. That is the fallback path
   app.html was written to degrade to, not a new code path.

   One envelope shape still has to render, though. When the engine cannot
   tell which entity you meant it returns an `ambiguous` envelope, and in
   app.html that mounts in the canvas. Left alone here it would be
   silently swallowed and the conversation would appear to stall. So it
   renders as a bot message instead, with the same clickable candidates.
   ============================================================ */

function esc(s){ return String(s).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c])); }
function candQuery(c){ if (c.entityType === "project") return "Show me project " + c.entityValue; return "Show me " + (c.entityValue || c.label); }

// Pull an envelope out of a flow response: `data` object (answer / web shapes),
// else decode the base64 fragment of the report.html link (chat shape).
function extractEnvelope(data) {
  try {
    if (data && data.data && typeof data.data === "object" && (Array.isArray(data.data.sections) || (data.data.ambiguous && Array.isArray(data.data.candidates)))) return data.data;
    const link = data && (data.link || data.url);
    if (typeof link === "string") {
      const hi = link.indexOf("#");
      if (hi >= 0 && hi < link.length - 1) {
        let b = decodeURIComponent(link.slice(hi + 1)).replace(/ /g, "+").replace(/[^A-Za-z0-9+/]/g, "");
        while (b.length % 4) b += "=";
        const env = JSON.parse(decodeURIComponent(escape(atob(b))));
        if (env && (Array.isArray(env.sections) || (env.ambiguous && Array.isArray(env.candidates)))) return env;
      }
    }
  } catch (e) { /* not an envelope — fine */ }
  return null;
}

function renderCandidateCard(env) {
  const cands = (env.candidates || []).filter(c => c && (c.label || c.entityValue));
  if (!cands.length) return null;
  const card = document.createElement("div");
  card.className = "rcard";
  let html = '<div><div class="r-eyebrow"><span>AMBIGUOUS MATCH</span><span>&middot;</span><b>' + cands.length + ' POSSIBLE</b></div>' +
             '<div class="r-name">Which one do you mean?</div></div>';
  html += '<div class="rcand">';
  cands.forEach(c => {
    const q = candQuery(c);
    html += '<button type="button" class="cand" data-cand-q="' + esc(q) + '" title="' + esc(q) + '">' +
            '<span class="ct"><span class="cl">' + esc(c.label || c.entityValue) + '</span>' +
            (c.hint ? '<span class="ch">' + esc(c.hint) + '</span>' : '') + '</span>' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg></button>';
  });
  html += '</div><div class="rdrill"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 3 14h7l-1 8 10-12h-7z"/></svg>Tap the one you mean &mdash; I&rsquo;ll pull that report.</div>';
  card.innerHTML = html;
  card.querySelectorAll(".cand").forEach(btn => {
    btn.addEventListener("click", () => send(btn.getAttribute("data-cand-q")));
  });
  return card;
}

// Mount a card as a full-width bot message in the thread.
function mountInChat(node) {
  const wrap = document.createElement("div");
  wrap.className = "msg msg--bot msg--report";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.appendChild(node);
  wrap.appendChild(bubble);
  logEl.appendChild(wrap);
  logEl.scrollTop = logEl.scrollHeight;
  return wrap;
}

function tryRenderEnvelope(data) {
  try {
    const env = extractEnvelope(data);
    if (!env || !env.ambiguous) return;   // reports are delivered as links on this page
    const pick = renderCandidateCard(env);
    if (pick) mountInChat(pick);
  } catch (e) { /* best-effort; chat behaviour unchanged either way */ }
}

'''

# ---------------------------------------------------------------- assemble
out = []
out += lines[:css_layout_a]                 # head + tokens + body reset
out += NEW_LAYOUT.split("\n")[:-1]
out += lines[hdr_a:print_a]                 # chat CSS + all report-card CSS
out += NEW_PRINT.split("\n")[:-1]
out += lines[print_b:canvas_a]              # reduced-motion, </style>, head, .app, .chat markup
out += lines[canvas_close + 1:js_a]         # </div> for .app, <script>, CONFIG, chat JS
out += NEW_JS.split("\n")[:-1]
out += lines[js_b:]                         # init + closing tags

text = "\n".join(out)

# title: distinguish the tab when both pages are open side by side for filming
text = text.replace("<title>Report Assistant</title>",
                    "<title>Report Assistant — Chat</title>", 1)

OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(text, encoding="utf-8")

# ---------------------------------------------------------------- validate
print(f"wrote {OUT}  {len(text.encode())} bytes")

m = re.search(r"<script>(.*)</script>", text, re.S)
if not m:
    sys.exit("!! no <script> block in output")
js = Path("/home/claude/out/_check.js")
js.write_text(m.group(1), encoding="utf-8")
r = subprocess.run(["node", "--check", str(js)], capture_output=True, text=True)
print("node --check:", "PASS" if r.returncode == 0 else "FAIL\n" + r.stderr)

# no orphaned references to the removed canvas / report machinery
orphans = ["mountReport", "renderEnvelopeCard", "setPrintable", "finalizeForPrint",
           "doPrint", "toggleSources", "wireTools", "wireKpis", "wireBars",
           "wireTrends", "wireTable", "wireKpiDrills", "wireChartDrills",
           "wireStatusDrills", "buildBarCharts", 'id="report"', 'id="canvas"',
           'id="rtools"', 'id="printBtn"', 'id="srcBtn"', 'id="empty"']
hits = [o for o in orphans if o in text]
print("orphan refs:", "none" if not hits else hits)

for tag in ["<style>", "</style>", "<script>", "</script>", "</body>", "</html>"]:
    n = text.count(tag)
    if n != 1:
        print(f"  !! {tag} appears {n}x")

opens = text.count("<div")
closes = text.count("</div>")
print(f"div open/close: {opens}/{closes}")
